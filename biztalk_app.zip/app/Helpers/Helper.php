<?php

class Helper
{
    public static function ApiSuccessStatus()
    {
        $apistatus = "success";

        return $apistatus;
    }

    public static function ApiFailedStatus()
    {
        $apistatus = "failed";

        return $apistatus;
    }
//
    public static function ApiErrorStatus()
    {
        $apistatus = "error";

        return $apistatus;
    }

}
